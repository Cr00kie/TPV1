// Adrian Isasi Martinez
// Grupo: G31

//
// Tecnología de la Programación de Videojuegos 1
// Facultad de Informática UCM
//
// Plantilla de proyecto con SDL
//

// TODO
// - [ ] cambiar a Game::CONSTANTE
// - [ ] checkCollisions en la rana
// - [ ] nNidosAlive variable de game
// - [ ] Contar tiempo de update y hacer bien el SDL_DELAY
// - [ ] Set is active de homedFrog en la propia homedFrog


#include "game.h"

int main(int argc, char* argv[])
{
	try {
		Game().run();
	}
	catch (std::string e) {
		std::cout << e;
	}

	return 0;
}
