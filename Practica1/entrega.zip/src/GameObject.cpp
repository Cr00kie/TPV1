#include "GameObject.h"
#include "GameState.h"

GameObject::GameObject(GameState* g) : m_pGame(g) {}
